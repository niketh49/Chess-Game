#include "tile.h"
#include <QGraphicsScene>
#include <QGraphicsTextItem>
#include <string>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <iostream>
#include <QtWidgets>
#include <QColor>
using namespace std;

tile::tile()
{

}

void tile::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED(event);

    emit TileSelected(this);
}

QRectF tile::boundingRect() const
{
    return QRectF(x_*70, y_*70, width_, width_);
}

// define the actual shape of the object
QPainterPath tile::shape() const
{
    QPainterPath path;
    path.addRect(x_*70, y_*70, width_, width_);
    return path;
}

// called by Qt to actually display the point
void tile::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(widget);
    Q_UNUSED(option);

    QBrush b = painter->brush();
    // update the line for setBrush to be this
    QColor nC = QColor(255, 255, 51);
    nC.setAlphaF(.8);
    painter->setBrush(QBrush(nC));

    painter->drawRect(QRect(this->x_*70, this->y_*70, this->width_, this->width_));
    painter->setBrush(b);
}
