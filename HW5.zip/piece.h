#ifndef PIECE_H
#define PIECE_H

#include <QColor>
#include <QGraphicsItem>
#include <bits/stdc++.h>
#include <vector>
#include "tile.h"
using namespace std;

enum color {
    Black,
    White
};

enum type {
    pawn,
    knight,
    bishop,
    rook,
    queen,
    king
};

class Piece: public QObject, public QGraphicsItem {

    // this makes it so that we can emit signals
    Q_OBJECT

public:
    Piece();  // constructor
    Piece(color PieceColor,enum type PieceType, int x, int y) {color_ = PieceColor,type_ = PieceType, x_pos=x, y_pos=y;}

    QRectF boundingRect() const override;
    QPainterPath shape() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *item, QWidget *widget) override;
    void showLegal(Piece* Pieceboard[8][8]);
    enum type getType() {return type_;}
    color getColor() {return color_;}
    int getX() {return x_pos;}
    int getY() {return y_pos;}
    void setX(int x) {x_pos = x;}
    void setY(int y) {y_pos = y;}
    vector< pair<int, int>> getMoves() {return moves;}

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    int x_pos;
    int y_pos;
    color color_;
    enum type type_;
    static int const width_ = 65;
    vector< pair<int, int>> moves;
signals:
    void PieceSelected(Piece *p);

};  // class Point
#endif // PIECE_H
