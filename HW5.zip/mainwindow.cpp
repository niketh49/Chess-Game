#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "piece.h"
#include "tile.h"
#include <QColor>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QGraphicsView *view = ui->graphicsView;
    scene = new QGraphicsScene;

    //Initialize Array of pieces to 0, usefull for later to check if location is empty or not
    for(int i=0; i<8; i++) {
        for(int j=0; j<8; j++) {
            Pieceboard[i][j] = nullptr;
        }
    }

    view->setScene(scene);
    view->setSceneRect(0,0,view->frameSize().width(), view->frameSize().height());

    //Drawing Lines
    int x_space = view->frameSize().width()/8;
    int y_space = view->frameSize().height()/8;

    //Vertical
    for(int i=0; i<=8; i++) {
        scene->addLine(i*x_space, 0, i*x_space, view->frameSize().height());
    }

    //Horizontal
    for(int i=0; i<=8; i++) {
        scene->addLine(0, i*y_space, view->frameSize().width(), i*y_space);
    }

    QBrush *brush = new QBrush(Qt::blue);

    //Creating Checkerboard
    for(int i=0; i<8; i++) {
        for(int j=0; j<8; j++) {
            board[i][j] = i+j;
            if(board[i][j]%2 == 1) {
                QRect r(j*y_space,i*x_space,70,70);
                scene->addRect(r, QPen(), *brush);
            }
        }
    }


    //Creating all Pieces
    for(int i=0; i<8; i++) {
        Piece *whitepawn= new Piece(color::White, type::pawn, i, 6);
        Pieceboard[6][i] = whitepawn;
        scene->addItem(whitepawn);
        connect(whitepawn, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    }
    Piece *whiterook1 = new Piece(color::White,type::rook, 0, 7);
    Pieceboard[7][0] = whiterook1;
    scene->addItem(whiterook1);
    Piece *whiterook2 = new Piece(color::White,type::rook, 7, 7);
    Pieceboard[7][7] = whiterook2;
    scene->addItem(whiterook2);

    Piece *whiteknight1 = new Piece(color::White,type::knight, 1, 7);
    Pieceboard[7][1] = whiteknight1;
    scene->addItem(whiteknight1);
    Piece *whiteknight2 = new Piece(color::White,type::knight, 6, 7);
    Pieceboard[7][6] = whiteknight2;
    scene->addItem(whiteknight2);

    Piece *whitebishop1 = new Piece(color::White,type::bishop, 2, 7);
    Pieceboard[7][2] = whitebishop1;
    scene->addItem(whitebishop1);
    Piece *whitebishop2 = new Piece(color::White,type::bishop, 5, 7);
    Pieceboard[7][5] = whitebishop2;
    scene->addItem(whitebishop2);

    Piece *whiteking = new Piece(color::White,type::king, 3, 7);
    Pieceboard[7][3] = whiteking;
    scene->addItem(whiteking);
    Piece *whitequeen = new Piece(color::White,type::queen, 4, 7);
    Pieceboard[7][4] = whitequeen;
    scene->addItem(whitequeen);

    //------------------------------------------------------------------------------------------------------------------

    for(int i=0; i<8; i++) {
        Piece *blackpawn= new Piece(color::Black, type::pawn, i, 1);
        Pieceboard[1][i] = blackpawn;
        scene->addItem(blackpawn);
        connect(blackpawn, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    }
    Piece *blackrook1 = new Piece(color::Black,type::rook, 0, 0);
    Pieceboard[0][0] = blackrook1;
    scene->addItem(blackrook1);
    Piece *blackrook2 = new Piece(color::Black,type::rook, 7, 0);
    Pieceboard[0][7] = blackrook2;
    scene->addItem(blackrook2);

    Piece *blackknight1 = new Piece(color::Black,type::knight, 1, 0);
    Pieceboard[0][1] = blackknight1;
    scene->addItem(blackknight1);
    Piece *blackknight2 = new Piece(color::Black,type::knight, 6, 0);
    Pieceboard[0][6] = blackknight2;
    scene->addItem(blackknight2);

    Piece *blackbishop1 = new Piece(color::Black,type::bishop, 2, 0);
    Pieceboard[0][2] = blackbishop1;
    scene->addItem(blackbishop1);
    Piece *blackbishop2 = new Piece(color::Black,type::bishop, 5, 0);
    Pieceboard[0][5] = blackbishop2;
    scene->addItem(blackbishop2);

    Piece *blackking = new Piece(color::Black,type::king, 3, 0);
    Pieceboard[0][3] = blackking;
    scene->addItem(blackking);
    Piece *blackqueen = new Piece(color::Black,type::queen, 4, 0);
    Pieceboard[0][4] = blackqueen;
    scene->addItem(blackqueen);


    //Connecting all pieces and their signals to slot
    connect(whiterook1, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(whiterook2, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(whiteknight1, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(whiteknight2, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(whitebishop1, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(whitebishop2, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(whiteking, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(whitequeen, &Piece::PieceSelected, this, &MainWindow::ShowMoves);

    connect(blackrook1, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(blackrook2, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(blackknight1, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(blackknight2, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(blackbishop1, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(blackbishop2, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(blackking, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
    connect(blackqueen, &Piece::PieceSelected, this, &MainWindow::ShowMoves);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::ShowMoves(Piece *p) {
    currPiece = p;
    p->showLegal(Pieceboard);
    for(unsigned int i=0; i<p->getMoves().size(); i++) {
        tile *t = new tile(p->getMoves()[i].first, p->getMoves()[i].second);
        tMoves.push_back(t);
        scene->addItem(t);
        connect(t,&tile::TileSelected,this,&MainWindow::MovePiece);
    }


}


void MainWindow::MovePiece(tile *t) {
    scene->removeItem(currPiece);
    scene->removeItem(Pieceboard[t->getY()][t->getX()]);
    Pieceboard[currPiece->getY()][currPiece->getX()] = nullptr;
    currPiece->setX(t->getX());
    currPiece->setY(t->getY());
    scene->addItem(currPiece);
    scene->update();
    Pieceboard[t->getY()][t->getX()] = currPiece;
    for(unsigned int i=0; i<tMoves.size(); i++) {
        scene->removeItem(tMoves[i]);
        tMoves[i] = NULL;
    }

}

