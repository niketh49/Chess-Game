#ifndef TILE_H
#define TILE_H


#include <QColor>
#include <QGraphicsItem>
#include <bits/stdc++.h>
#include <vector>
using namespace std;

class tile: public QObject, public QGraphicsItem {
    Q_OBJECT
public:
    tile();
    tile(int x, int y) {x_ = x, y_ = y;}
    QRectF boundingRect() const;
    QPainterPath shape() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *item, QWidget *widget);
    int getX() {return x_;}
    int getY() {return y_;}

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    static int const width_ = 70;
    int x_;
    int y_;
signals:
    void TileSelected(tile *t); //Select tile to moves to
};

#endif // TILE_H
