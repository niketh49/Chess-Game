#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "piece.h"
#include <vector>
#include <QColor>
using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    int board[8][8]; // Used to create checkerboard
    Piece* Pieceboard[8][8]; //Array of pieces
    QGraphicsScene *scene;
    Piece *currPiece;
    vector<tile*> tMoves; //List of moves
private slots:
    void ShowMoves(Piece *p); //Shows all possible moves on screen
    void MovePiece(tile *t); //Moves the piece
};
#endif // MAINWINDOW_H
