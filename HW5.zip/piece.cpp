#include "piece.h"
#include <QtWidgets>

Piece::Piece()
{
    x_pos = 0;
    y_pos = 0;
}


void Piece::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED(event);

    emit PieceSelected(this); //Piece slected
}


// where is this object located
// always a rectangle, Qt uses this to know "where" the user
// would be interacting with this object
QRectF Piece::boundingRect() const
{
    return QRectF(x_pos*70, y_pos*70, width_, width_);
}

// define the actual shape of the object
QPainterPath Piece::shape() const
{
    QPainterPath path;
    path.addRect(x_pos*70, y_pos*70, width_, width_);
    return path;
}

// called by Qt to actually display the point
void Piece::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(widget);
    Q_UNUSED(option);


    //Creating display for all the pieces
    if(color_ == color::Black) {
        if(type_ == type::king) {
            QPixmap img(":/BlackKing.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::queen) { //-------------------
            QPixmap img(":/newBlackQueen.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::pawn) { //------------------------
            QPixmap img(":/newBlackPawn.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::knight) { //--------------------
            QPixmap img(":/newBlackKnight.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::bishop) {
            QPixmap img(":/BlackBishop.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::rook) {
            QPixmap img(":/BlackRook.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
    }
    else if(color_ == color::White) {
        if(type_ == type::king) {
            QPixmap img(":/WhiteKing.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::queen) {
            QPixmap img(":/WhiteQueen.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::pawn) { //---------------------------
            QPixmap img(":/newWhitePawn.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::knight) {
            QPixmap img(":/WhiteKnight.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::bishop) {
            QPixmap img(":/WhiteBishop.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
        else if(type_ == type::rook) {
            QPixmap img(":/WhiteRook.png");
            painter->drawPixmap(x_pos*70,y_pos*70,width_,width_, img);
        }
    }
}

void Piece::showLegal(Piece* Pieceboard[8][8]) {

    //Clearing moves so we can reset
    moves.clear();

    //Entering all legal moves
    if(type_ == type::pawn) {
        if(color_ == color::White) {
            if(Pieceboard[y_pos-1][x_pos] == nullptr) {
                pair<int, int> lMove (x_pos, y_pos-1);
                moves.push_back(lMove);
            }

            if(Pieceboard[y_pos-1][x_pos-1] != nullptr) { //Diagonal Take
                qDebug() << "im in";
                 if(Pieceboard[y_pos-1][x_pos-1]->getColor() == color::Black) {
                    pair<int, int> lMove (x_pos-1, y_pos-1);
                    moves.push_back(lMove);
                 }
            }
            if(Pieceboard[y_pos-1][x_pos+1] != nullptr) { //Diagonal Take
                 if(Pieceboard[y_pos-1][x_pos+1]->getColor() == color::Black) {
                    pair<int, int> lMove (x_pos+1, y_pos-1);
                    moves.push_back(lMove);
                 }
            }

        }
        else {
            if(Pieceboard[y_pos+1][x_pos] == nullptr) {
                pair<int, int> lMove (x_pos, y_pos+1);
                moves.push_back(lMove);
            }


            if(Pieceboard[y_pos+1][x_pos-1] != nullptr) { //Diagonal Take
                if(Pieceboard[y_pos+1][x_pos-1]->getColor() == color::White) {
                    pair<int, int> lMove (x_pos-1, y_pos+1);
                    moves.push_back(lMove);
                }
            }
            if(Pieceboard[y_pos+1][x_pos+1] != nullptr) { //Diagonal Take
                 if(Pieceboard[y_pos+1][x_pos+1]->getColor() == color::White) {
                    pair<int, int> lMove (x_pos+1, y_pos+1);
                    moves.push_back(lMove);
                 }
            }

        }
    }
    else if(type_ == type::knight) {
        int nX = this->x_pos;
        int nY = this->y_pos;
        if(nY+2<=7 && nX-1>=0) { // Within bounds
            if(Pieceboard[nY+2][nX-1] != nullptr) { //If theres a piece there
                if(Pieceboard[nY+2][nX-1]->getColor() != color_) { // different color
                    pair<int, int> lMove (nX-1, nY+2);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX-1, nY+2);
                moves.push_back(lMove);
            }
        }
        if(nY+2<=7 && nX+1<=7) {
            if(Pieceboard[nY+2][nX+1] != nullptr) {
                if(Pieceboard[nY+2][nX+1]->getColor() != color_) {
                    pair<int, int> lMove (nX-1, nY+2);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX+1, nY+2);
                moves.push_back(lMove);
            }
        }
        if(nY+1<=7 && nX+2<=7) {
            if(Pieceboard[nY+1][nX+2] != nullptr) {
                if(Pieceboard[nY+1][nX+2]->getColor() != color_) {
                    pair<int, int> lMove (nX+2, nY+1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX+2, nY+1);
                moves.push_back(lMove);
            }
        }
        if(nY-1>=0 && nX+2<=7) {
            if(Pieceboard[nY-1][nX+2] != nullptr) {
                if(Pieceboard[nY-1][nX+2]->getColor() != color_) {
                    pair<int, int> lMove (nX+2, nY-1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX+2, nY-1);
                moves.push_back(lMove);
            }
        }
        if(nY-2>=0 && nX+1<=7) {
            if(Pieceboard[nY-2][nX+1] != nullptr) {
                if(Pieceboard[nY-2][nX+1]->getColor() != color_) {
                    pair<int, int> lMove (nX-1, nY+2);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX+1, nY-2);
                moves.push_back(lMove);
            }
        }
        if(nY-2>=0 && nX-1>=0) {
            if(Pieceboard[nY-2][nX-1] != nullptr) {
                if(Pieceboard[nY-2][nX-1]->getColor() != color_) {
                    pair<int, int> lMove (nX-1, nY-2);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX-1, nY-2);
                moves.push_back(lMove);
            }
        }
        if(nY+1<=7 && nX-2>=0) {
            if(Pieceboard[nY+1][nX-2] != nullptr) {
                if(Pieceboard[nY+1][nX-2]->getColor() != color_) {
                    pair<int, int> lMove (nX-2, nY+1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX-2, nY+1);
                moves.push_back(lMove);
            }
        }
        if(nY-1>=0 && nX-2>=0) {
            if(Pieceboard[nY-1][nX-2] != nullptr) {
                if(Pieceboard[nY-1][nX-2]->getColor() != color_) {
                    pair<int, int> lMove (nX-2, nY-1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX-2, nY-1);
                moves.push_back(lMove);
            }
        }
    }
    else if(type_ == type::bishop) {
        int oneX = this->x_pos;
        int oneY = this->y_pos;
        while(1) { //Looping diagonally
            oneX++;
            oneY++;
            if(oneX>=0 && oneX<=7 && oneY>=0 && oneY<=7) { //In bounds
                if(Pieceboard[oneY][oneX] != nullptr) { //If not empty
                    if(Pieceboard[oneY][oneX]->getColor() == color_) { //Ally piece
                        break;
                    }
                    if(Pieceboard[oneY][oneX]->getColor() != color_) { //Enemy Piece
                        pair<int, int> lMove (oneX, oneY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (oneX, oneY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int twoX = this->x_pos;
        int twoY = this->y_pos;
        while(1) {
            twoX--;
            twoY++;
            if(twoX>=0 && twoX<=7 && twoY>=0 && twoY<=7) {
                if(Pieceboard[twoY][twoX] != nullptr) {
                    if(Pieceboard[twoY][twoX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[twoY][twoX]->getColor() != color_) {
                        pair<int, int> lMove (twoX, twoY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (twoX, twoY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int threeX = this->x_pos;
        int threeY = this->y_pos;
        while(1) {
            threeX++;
            threeY--;
            if(threeX>=0 && threeX<=7 && threeY>=0 && threeY<=7) {
                if(Pieceboard[threeY][threeX] != nullptr) {
                    if(Pieceboard[threeY][threeX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[threeY][threeX]->getColor() != color_) {
                        pair<int, int> lMove (threeX, threeY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (threeX, threeY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int fourX = this->x_pos;
        int fourY = this->y_pos;
        while(1) {
            fourX--;
            fourY--;
            if(fourX>=0 && fourX<=7 && fourY>=0 && fourY<=7) {
                if(Pieceboard[fourY][fourX] != nullptr) {
                    if(Pieceboard[fourY][fourX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[fourY][fourX]->getColor() != color_) {
                        pair<int, int> lMove (fourX, fourY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (fourX, fourY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }
    }
    else if(type_ == type::rook) {
        int oneX = this->x_pos;
        while(1) { //Looping, same structure as Bishop
            oneX++;
            if(oneX>=0 && oneX<=7) {
                if(Pieceboard[y_pos][oneX] != nullptr) {
                    if(Pieceboard[y_pos][oneX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[y_pos][oneX]->getColor() != color_) {
                        pair<int, int> lMove (oneX, y_pos);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (oneX, y_pos);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int twoX = this->x_pos;
        while(1) {
            twoX--;
            if(twoX>=0 && twoX<=7) {
                if(Pieceboard[y_pos][twoX] != nullptr) {
                    if(Pieceboard[y_pos][twoX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[y_pos][twoX]->getColor() != color_) {
                        pair<int, int> lMove (twoX, y_pos);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (twoX, y_pos);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int oneY = this->y_pos;
        while(1) {
            oneY++;
            if(oneY>=0 && oneY<=7) {
                if(Pieceboard[oneY][x_pos] != nullptr) {
                    if(Pieceboard[oneY][x_pos]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[oneY][x_pos]->getColor() != color_) {
                        pair<int, int> lMove (x_pos, oneY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (x_pos, oneY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int twoY = this->y_pos;
        while(1) {
            twoY--;
            if(twoY>=0 && twoY<=7) {
                if(Pieceboard[twoY][x_pos] != nullptr) {
                    if(Pieceboard[twoY][x_pos]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[twoY][x_pos]->getColor() != color_) {
                        pair<int, int> lMove (x_pos, twoY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (x_pos, twoY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

    }
    else if(type_ == type::queen) { //Same Structure as bishop and rook
        int oneX = this->x_pos;
        int oneY = this->y_pos;
        while(1) {
            oneX++;
            oneY++;
            if(oneX>=0 && oneX<=7 && oneY>=0 && oneY<=7) {
                if(Pieceboard[oneY][oneX] != nullptr) {
                    if(Pieceboard[oneY][oneX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[oneY][oneX]->getColor() != color_) {
                        pair<int, int> lMove (oneX, oneY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (oneX, oneY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int twoX = this->x_pos;
        int twoY = this->y_pos;
        while(1) {
            twoX--;
            twoY++;
            if(twoX>=0 && twoX<=7 && twoY>=0 && twoY<=7) {
                if(Pieceboard[twoY][twoX] != nullptr) {
                    if(Pieceboard[twoY][twoX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[twoY][twoX]->getColor() != color_) {
                        pair<int, int> lMove (twoX, twoY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (twoX, twoY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int threeX = this->x_pos;
        int threeY = this->y_pos;
        while(1) {
            threeX++;
            threeY--;
            if(threeX>=0 && threeX<=7 && threeY>=0 && threeY<=7) {
                if(Pieceboard[threeY][threeX] != nullptr) {
                    if(Pieceboard[threeY][threeX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[threeY][threeX]->getColor() != color_) {
                        pair<int, int> lMove (threeX, threeY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (threeX, threeY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int fourX = this->x_pos;
        int fourY = this->y_pos;
        while(1) {
            fourX--;
            fourY--;
            if(fourX>=0 && fourX<=7 && fourY>=0 && fourY<=7) {
                if(Pieceboard[fourY][fourX] != nullptr) {
                    if(Pieceboard[fourY][fourX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[fourY][fourX]->getColor() != color_) {
                        pair<int, int> lMove (fourX, fourY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (fourX, fourY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        //-------------------------------------------------------------------------

        int soneX = this->x_pos;
        while(1) {
            soneX++;
            if(soneX>=0 && soneX<=7) {
                if(Pieceboard[y_pos][soneX] != nullptr) {
                    if(Pieceboard[y_pos][soneX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[y_pos][soneX]->getColor() != color_) {
                        pair<int, int> lMove (soneX, y_pos);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (soneX, y_pos);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int stwoX = this->x_pos;
        while(1) {
            stwoX--;
            if(stwoX>=0 && stwoX<=7) {
                if(Pieceboard[y_pos][stwoX] != nullptr) {
                    if(Pieceboard[y_pos][stwoX]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[y_pos][stwoX]->getColor() != color_) {
                        pair<int, int> lMove (stwoX, y_pos);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (stwoX, y_pos);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int soneY = this->y_pos;
        while(1) {
            soneY++;
            if(soneY>=0 && soneY<=7) {
                if(Pieceboard[soneY][x_pos] != nullptr) {
                    if(Pieceboard[soneY][x_pos]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[soneY][x_pos]->getColor() != color_) {
                        pair<int, int> lMove (x_pos, soneY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (x_pos, soneY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

        int stwoY = this->y_pos;
        while(1) {
            stwoY--;
            if(stwoY>=0 && stwoY<=7) {
                if(Pieceboard[stwoY][x_pos] != nullptr) {
                    if(Pieceboard[stwoY][x_pos]->getColor() == color_) {
                        break;
                    }
                    if(Pieceboard[stwoY][x_pos]->getColor() != color_) {
                        pair<int, int> lMove (x_pos, stwoY);
                        moves.push_back(lMove);
                        break;
                    }
                }
                else {
                    pair<int, int> lMove (x_pos, stwoY);
                    moves.push_back(lMove);
                }
            }
            else {
                break;
            }
        }

    }

    else if(type_ == type::king) { //Checks all individual moves.
        int nX = this->x_pos;
        int nY = this->y_pos;
        if(nY+1<=7) {
            if(Pieceboard[nY+1][nX] != nullptr) {
                if(Pieceboard[nY+1][nX]->getColor() != color_) {
                    pair<int, int> lMove (nX, nY+1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX, nY+1);
                moves.push_back(lMove);
            }
        }
        if(nY-1>=0) {
            if(Pieceboard[nY-1][nX] != nullptr) {
                if(Pieceboard[nY-1][nX]->getColor() != color_) {
                    pair<int, int> lMove (nX, nY-1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX, nY-1);
                moves.push_back(lMove);
            }
        }
        if(nX+1<=7) {
            if(Pieceboard[nY][nX+1] != nullptr) {
                if(Pieceboard[nY][nX+1]->getColor() != color_) {
                    pair<int, int> lMove (nX+1, nY);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX+1, nY);
                moves.push_back(lMove);
            }
        }
        if(nX-1>=0) {
            if(Pieceboard[nY][nX-1] != nullptr) {
                if(Pieceboard[nY][nX-1]->getColor() != color_) {
                    pair<int, int> lMove (nX-1, nY);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX-1, nY);
                moves.push_back(lMove);
            }
        }
        if(nY+1<=7 && nX+1<=7) {
            if(Pieceboard[nY+1][nX+1] != nullptr) {
                if(Pieceboard[nY+1][nX+1]->getColor() != color_) {
                    pair<int, int> lMove (nX+1, nY+1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX+1, nY+1);
                moves.push_back(lMove);
            }
        }
        if(nY+1<=7 && nX-1>=0) {
            if(Pieceboard[nY+1][nX-1] != nullptr) {
                if(Pieceboard[nY+1][nX-1]->getColor() != color_) {
                    pair<int, int> lMove (nX-1, nY+1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX-1, nY+1);
                moves.push_back(lMove);
            }
        }
        if(nY-1>=0 && nX+1<=7) {
            if(Pieceboard[nY-1][nX+1] != nullptr) {
                if(Pieceboard[nY-1][nX+1]->getColor() != color_) {
                    pair<int, int> lMove (nX+1, nY-1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX+1, nY-1);
                moves.push_back(lMove);
            }
        }
        if(nY-1>=0 && nX-1>=0) {
            if(Pieceboard[nY-1][nX-1] != nullptr) {
                if(Pieceboard[nY-1][nX-1]->getColor() != color_) {
                    pair<int, int> lMove (nX-1, nY-1);
                    moves.push_back(lMove);
                }
            }
            else {
                pair<int, int> lMove (nX-1, nY-1);
                moves.push_back(lMove);
            }
        }
    }
}


